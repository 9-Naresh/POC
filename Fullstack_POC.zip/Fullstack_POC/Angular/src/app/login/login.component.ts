import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {UserService} from '../service/user.service';
import {first} from 'rxjs/operators';
import {User} from '../model/user.model';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})



export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  invalidLogin = false;
  users: User[];
  validateUser: any;
  testUsers: User[];
  
  // constructor(private formBuilder: FormBuilder, private router: Router, private authService: AuthenticationService) { }
constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserService) { }

  onSubmit() {



    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }

    
    this.userService.getUsers().subscribe(data=>{
      
      //this.userr.map((data)=>data);
      //this.users=data;
      console.log(data);
      this.users= data.filter(u=>u.email===this.loginForm.controls.email.value && u.password===this.loginForm.controls.password.value);     
      //this.users.map(data=>data.email);

    if (this.loginForm.controls.email.value === 'mail@mail.com' && this.loginForm.controls.password.value === 'password') {
        this.router.navigate(['list-user']);
    }
    else if(this.users.length>0)
    {
      this.router.navigate(['list-user']);
    }    
    else {
      this.invalidLogin = true;
    }
    });

    // this.userService.getUsers().subscribe(allUsers=>{
      
    //   (allUsers.push(au=>{this.testUsers=au}));    
      
    // });

    console.log(this.testUsers);

  }
  ngOnInit() {

    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }




}
